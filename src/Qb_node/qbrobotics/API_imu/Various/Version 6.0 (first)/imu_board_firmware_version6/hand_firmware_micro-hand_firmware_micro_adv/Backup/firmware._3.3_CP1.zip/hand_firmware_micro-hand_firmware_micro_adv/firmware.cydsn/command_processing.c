// ----------------------------------------------------------------------------
// Copyright (C)  qbrobotics. All rights reserved.
// www.qbrobotics.com
// ----------------------------------------------------------------------------


/**
* \file         command_processing.c
*

* \brief        Command processing functions.
* \date         May 16, 2016
* \author       qbrobotics
* \copyright    (C)  qbrobotics. All rights reserved.
*/

//=================================================================     includes
#include <command_processing.h>
#include <interruptions.h>
#include <stdio.h>
#include <utils.h>

#include "commands.h"

//================================================================     variables

reg8 * EEPROM_ADDR = (reg8 *) CYDEV_EE_BASE;

//==============================================================================
//                                                            RX DATA PROCESSING
//==============================================================================
//  This function checks for the availability of a data packet and process it:
//      - Verify checksum;
//      - Process commands;
//==============================================================================

void commProcess(){

    uint8 CYDATA rx_cmd;

    rx_cmd = g_rx.buffer[0];

//==========================================================     verify checksum

    if (!(LCRChecksum(g_rx.buffer, g_rx.length - 1) == g_rx.buffer[g_rx.length - 1])){
        // Wrong checksum
        g_rx.ready = 0;
        return;
    }


    switch(rx_cmd) {

//=============================================================     CMD_ACTIVATE
        case CMD_ACTIVATE:
            cmd_activate();
            break;

//===========================================================     CMD_SET_INPUTS

        case CMD_SET_INPUTS:
            cmd_set_inputs();
            break;

//=====================================================     CMD_GET_MEASUREMENTS

        case CMD_GET_MEASUREMENTS:
            cmd_get_measurements();
            break;

//=========================================================     CMD_GET_CURRENTS

        case CMD_GET_CURRENTS:
            cmd_get_currents();
            break;


//=========================================================     CMD_GET_EMG

        case CMD_GET_EMG:
            cmd_get_emg();
            break;

//=============================================================     CMD_WATCHDOG
            
        case CMD_SET_WATCHDOG:
            cmd_set_watchdog();
            break;
            
//=========================================================     CMD_GET_ACTIVATE
            
        case CMD_GET_ACTIVATE:
            cmd_get_activate();
            break;
            
//=========================================================     CMD_SET_BAUDRATE
            
        case CMD_SET_BAUDRATE:
            cmd_set_baudrate();
            break;  
            
//============================================================     CMD_GET_INPUT

        case CMD_GET_INPUTS:
            cmd_get_inputs();
            break;

//=============================================================     CMD_GET_INFO

        case CMD_GET_INFO:
            infoGet( *((uint16 *) &g_rx.buffer[1]));
            break;

//============================================================     CMD_SET_PARAM

        case CMD_SET_PARAM:
            paramSet( *((uint16 *) &g_rx.buffer[1]) );
            break;

//============================================================     CMD_GET_PARAM

        case CMD_GET_PARAM:
            paramGet( *((uint16 *) &g_rx.buffer[1]) );
            break;

//=================================================================     CMD_PING
            
        case CMD_PING:
            cmd_ping();
            break;

//=========================================================     CMD_STORE_PARAMS
            
        case CMD_STORE_PARAMS:
            cmd_store_params();
            break;

//=================================================     CMD_STORE_DEFAULT_PARAMS

        case CMD_STORE_DEFAULT_PARAMS:
            if(memStore(DEFAULT_EEPROM_DISPLACEMENT))
                sendAcknowledgment(ACK_OK);
            else
                sendAcknowledgment(ACK_ERROR);
            break;

//=======================================================     CMD_RESTORE_PARAMS

        case CMD_RESTORE_PARAMS:
            if(memRestore())
                sendAcknowledgment(ACK_OK);
            else
                sendAcknowledgment(ACK_ERROR);
            break;

//=============================================================     CMD_INIT_MEM

        case CMD_INIT_MEM:
            if(memInit())
                sendAcknowledgment(ACK_OK);
            else
                sendAcknowledgment(ACK_ERROR);
            break;

//===========================================================     CMD_BOOTLOADER

        case CMD_BOOTLOADER:
            //Not sure if ACK_OK is correct, should check
            sendAcknowledgment(ACK_OK);
            CyDelay(1000);
            FTDI_ENABLE_REG_Write(0x00);
            CyDelay(1000);
            Bootloadable_Load();
            break;

//============================================================     CMD_CALIBRATE

        case CMD_CALIBRATE:
            calib.speed = *((int16 *) &g_rx.buffer[1]);
            calib.repetitions = *((int16 *) &g_rx.buffer[3]);
            
            // Speed & repetitions saturations
            if (calib.speed < 0) {
                calib.speed = 0;
            } else if (calib.speed > 200) {
                calib.speed = 200;
            }
            if (calib.repetitions < 0) {
                calib.repetitions = 0;
            } else if (calib.repetitions > 32767) {
                calib.repetitions = 32767;
            }
            
            g_refNew.pos[0] = 0;
            calib.enabled = TRUE;
            break;
    }
}


//==============================================================================
//                                                                     INFO SEND
//==============================================================================

void infoSend(){
    unsigned char packet_string[1100];
    infoPrepare(packet_string);
    UART_RS485_PutString(packet_string);
}


//==============================================================================
//                                                              COMMAND GET INFO
//==============================================================================

void infoGet(uint16 info_type) {
    static unsigned char packet_string[1100];

    //==================================     choose info type and prepare string

    switch (info_type) {
        case INFO_ALL:
            infoPrepare(packet_string);
            UART_RS485_PutString(packet_string);
            break;

        default:
            break;
    }
}

//==============================================================================
//                                                        COMMAND SET PARAMETER
//==============================================================================


void paramSet(uint16 param_type)
{
    uint8 CYDATA i;        // iterator
    int32 aux_int;  // auxiliary variable
    uint8 aux_uchar;

    switch(param_type) {

//===================================================================     set_id

        case PARAM_ID:
            g_mem.id = g_rx.buffer[3];
            break;

//=======================================================     set_pid_parameters

        case PARAM_PID_CONTROL:
            if(c_mem.control_mode != CURR_AND_POS_CONTROL) {
                g_mem.k_p = *((double *) &g_rx.buffer[3]) * 65536;
                g_mem.k_i = *((double *) &g_rx.buffer[3 + 4]) * 65536;
                g_mem.k_d = *((double *) &g_rx.buffer[3 + 8]) * 65536;
            }
            else {
                g_mem.k_p_dl = *((double *) &g_rx.buffer[3]) * 65536;
                g_mem.k_i_dl = *((double *) &g_rx.buffer[3 + 4]) * 65536;
                g_mem.k_d_dl = *((double *) &g_rx.buffer[3 + 8]) * 65536;
            }
            break;

//==================================================     set_curr_pid_parameters

        case PARAM_PID_CURR_CONTROL:
            if(c_mem.control_mode != CURR_AND_POS_CONTROL){
                g_mem.k_p_c = *((double *) &g_rx.buffer[3]) * 65536;
                g_mem.k_i_c = *((double *) &g_rx.buffer[3 + 4]) * 65536;
                g_mem.k_d_c = *((double *) &g_rx.buffer[3 + 8]) * 65536;
            }   
            else {
                g_mem.k_p_c_dl = *((double *) &g_rx.buffer[3]) * 65536;
                g_mem.k_i_c_dl = *((double *) &g_rx.buffer[3 + 4]) * 65536;
                g_mem.k_d_c_dl = *((double *) &g_rx.buffer[3 + 8]) * 65536; 
            }
            break;

//===================================================     set_startup_activation

        case PARAM_STARTUP_ACTIVATION:
            g_mem.activ = g_rx.buffer[3];
            break;

//===========================================================     set_input_mode

        case PARAM_INPUT_MODE:
            g_mem.input_mode = g_rx.buffer[3];
            break;

//=========================================================     set_control_mode

        case PARAM_CONTROL_MODE:
            g_mem.control_mode = g_rx.buffer[3];
            break;

//===========================================================     set_resolution

        case PARAM_POS_RESOLUTION:
            for (i =0; i < NUM_OF_SENSORS; i++) {
                g_mem.res[i] = g_rx.buffer[i+3];
            }
            break;

//===============================================================     set_offset

        case PARAM_MEASUREMENT_OFFSET:
            for(i = 0; i < NUM_OF_SENSORS; ++i) {
                g_mem.m_off[i] = *((int16 *) &g_rx.buffer[3 + i * 2]);
                g_mem.m_off[i] = g_mem.m_off[i] << g_mem.res[i];

                g_meas.rot[i] = 0;
            }
            reset_last_value_flag = 1;
            break;

//===========================================================     set_multiplier

        case PARAM_MEASUREMENT_MULTIPLIER:
            for(i = 0; i < NUM_OF_SENSORS; ++i) {
                g_mem.m_mult[i] = *((double *) &g_rx.buffer[3 + i * 4]);
            }
            break;

//=====================================================     set_pos_limit_enable

        case PARAM_POS_LIMIT_FLAG:
            g_mem.pos_lim_flag = *((uint8 *) &g_rx.buffer[3]);
            break;

//============================================================     set_pos_limit

        case PARAM_POS_LIMIT:
            for (i = 0; i < NUM_OF_MOTORS; i++) {
                g_mem.pos_lim_inf[i] = *((int32 *) &g_rx.buffer[3 + (i * 2 * 4)]);
                g_mem.pos_lim_sup[i] = *((int32 *) &g_rx.buffer[3 + (i * 2 * 4) + 4]);

                g_mem.pos_lim_inf[i] = g_mem.pos_lim_inf[i] << g_mem.res[i];
                g_mem.pos_lim_sup[i] = g_mem.pos_lim_sup[i] << g_mem.res[i];

            }
            break;

//===============================================     set_max_step_pos_per_cycle

        case PARAM_MAX_STEP_POS:
            aux_int = *((int32 *) &g_rx.buffer[3]);
            if (aux_int >= 0) {
                g_mem.max_step_pos = aux_int;
            }
            break;

//===============================================     set_max_step_neg_per_cycle

        case PARAM_MAX_STEP_NEG:
            aux_int = *((int32 *) &g_rx.buffer[3]);
            if (aux_int <= 0) {
                g_mem.max_step_neg = aux_int;
            }
            break;

//========================================================     set_current_limit

        case PARAM_CURRENT_LIMIT:
            g_mem.current_limit = *((int16*) &g_rx.buffer[3]);
            break;

//=======================================================     set_emg_calib_flag

        case PARAM_EMG_CALIB_FLAG:
            g_mem.emg_calibration_flag = *((uint8*) &g_rx.buffer[3]);
            break;

//========================================================     set_emg_threshold

        case PARAM_EMG_THRESHOLD:
            g_mem.emg_threshold[0] = *((uint16*) &g_rx.buffer[3]);
            g_mem.emg_threshold[1] = *((uint16*) &g_rx.buffer[5]);
            break;

//========================================================     set_emg_max_value

        case PARAM_EMG_MAX_VALUE:
            g_mem.emg_max_value[0] = *((uint32*) &g_rx.buffer[3]);
            g_mem.emg_max_value[1] = *((uint32*) &g_rx.buffer[7]);
            break;

//============================================================     set_emg_speed

        case PARAM_EMG_SPEED:
            g_mem.emg_speed = *((uint8*) &g_rx.buffer[3]);
            break;

//================================================     set_double_encoder_on_off
        case PARAM_DOUBLE_ENC_ON_OFF:
            aux_uchar = *((uint8*) &g_rx.buffer[3]);
            if (aux_uchar) {
                g_mem.double_encoder_on_off = 1;
            } else {
                g_mem.double_encoder_on_off = 0;
            }
            break;

//===================================================     set_motor_handle_ratio
        case PARAM_MOT_HANDLE_RATIO:
            g_mem.motor_handle_ratio = *((int8*) &g_rx.buffer[3]);
            break;

//===================================================     set_motor_supply_type
        case PARAM_MOTOR_SUPPLY:
            g_mem.activate_pwm_rescaling = g_rx.buffer[3];
            break;

    }
    //Not sure if ACK_OK is correct, should check
    sendAcknowledgment(ACK_OK);
}


//==============================================================================
//                                                         COMMAND GET PARAMETER
//==============================================================================

void paramGet(uint16 param_type)
{
    uint8 packet_data[20];
    uint16 packet_lenght;
    uint8 i;                // iterator

    packet_data[0] = CMD_GET_PARAM;

    switch(param_type) {

//===================================================================     get_id

        case PARAM_ID:
            packet_data[1] = c_mem.id;
            packet_lenght = 3;
            break;

//=======================================================     get_pid_parameters

        case PARAM_PID_CONTROL:
            if(c_mem.control_mode != CURR_AND_POS_CONTROL) {
                *((double *) (packet_data + 1)) = (double) c_mem.k_p / 65536;
                *((double *) (packet_data + 5)) = (double) c_mem.k_i / 65536;
                *((double *) (packet_data + 9)) = (double) c_mem.k_d / 65536;
            }
            else {
                *((double *) (packet_data + 1)) = (double) c_mem.k_p_dl / 65536;
                *((double *) (packet_data + 5)) = (double) c_mem.k_i_dl / 65536;
                *((double *) (packet_data + 9)) = (double) c_mem.k_d_dl / 65536;
            }
            packet_lenght = 14;
            break;

//=======================================================     get_pid_parameters

        case PARAM_PID_CURR_CONTROL:
            if(c_mem.control_mode != CURR_AND_POS_CONTROL) {
                *((double *) (packet_data + 1)) = (double) c_mem.k_p_c / 65536;
                *((double *) (packet_data + 5)) = (double) c_mem.k_i_c / 65536;
                *((double *) (packet_data + 9)) = (double) c_mem.k_d_c / 65536;
            }
            else {
                *((double *) (packet_data + 1)) = (double) c_mem.k_p_c_dl / 65536;
                *((double *) (packet_data + 5)) = (double) c_mem.k_i_c_dl / 65536;
                *((double *) (packet_data + 9)) = (double) c_mem.k_d_c_dl / 65536;
            }    
            packet_lenght = 14;
            break;

//===================================================     get_startup_activation

        case PARAM_STARTUP_ACTIVATION:
            packet_data[1] = c_mem.activ;
            packet_lenght = 3;
            break;

//===========================================================     get_input_mode

        case PARAM_INPUT_MODE:
            packet_data[1] = c_mem.input_mode;
            packet_lenght = 3;
            break;

//=========================================================     get_control_mode

        case PARAM_CONTROL_MODE:
            packet_data[1] = c_mem.control_mode;
            packet_lenght = 3;
            break;

//===========================================================     get_resolution

        case PARAM_POS_RESOLUTION:
            for (i = 0; i < NUM_OF_SENSORS; i++) {
                packet_data[i+1] = c_mem.res[i];
            }
            packet_lenght = NUM_OF_SENSORS + 2;
            break;

//===============================================================     get_offset

        case PARAM_MEASUREMENT_OFFSET:
            for(i = 0; i < NUM_OF_SENSORS; ++i) {
                *((int16 *) ( packet_data + 1 + (i * 2) )) = (int16) (c_mem.m_off[i] >> c_mem.res[i]);
            }

            packet_lenght = 2 + NUM_OF_SENSORS * 2;
            break;

//===========================================================     get_multiplier

        case PARAM_MEASUREMENT_MULTIPLIER:
            for(i = 0; i < NUM_OF_SENSORS; ++i) {
                *((double *) ( packet_data + 1 + (i * 4) )) = c_mem.m_mult[i];
            }

            packet_lenght = 2 + NUM_OF_SENSORS * 4;
            break;

//=====================================================     get_pos_limit_enable

        case PARAM_POS_LIMIT_FLAG:
            packet_data[1] = c_mem.pos_lim_flag;
            packet_lenght = 3;
            break;

//============================================================     get_pos_limit

        case PARAM_POS_LIMIT:
            for (i = 0; i < NUM_OF_MOTORS; i++) {
                *((int32 *)( packet_data + 1 + (i * 2 * 4) )) = c_mem.pos_lim_inf[i];
                *((int32 *)( packet_data + 1 + (i * 2 * 4) + 4)) = c_mem.pos_lim_sup[i];
            }
            packet_lenght = 2 + (NUM_OF_MOTORS * 2 * 4);
            break;

//=========================================================     get_max_step_pos

        case PARAM_MAX_STEP_POS:
            *((int32 *)(packet_data + 1)) = c_mem.max_step_pos;
            packet_lenght = 6;
            break;

//=========================================================     get_max_step_neg

        case PARAM_MAX_STEP_NEG:
            *((int32 *)(packet_data + 1)) = c_mem.max_step_neg;
            packet_lenght = 6;
            break;

//========================================================     get_current_limit

        case PARAM_CURRENT_LIMIT:
            *((int16 *)(packet_data + 1)) = c_mem.current_limit;
            packet_lenght = 4;
            break;

//=======================================================     get_emg_calib_flag

        case PARAM_EMG_CALIB_FLAG:
            *((uint8 *)(packet_data + 1)) = c_mem.emg_calibration_flag;
            packet_lenght = 3;
            break;

//========================================================     get_emg_threshold

        case PARAM_EMG_THRESHOLD:
            *((uint16 *)(packet_data + 1)) = c_mem.emg_threshold[0];
            *((uint16 *)(packet_data + 3)) = c_mem.emg_threshold[1];
            packet_lenght = 6;
            break;

//========================================================     get_emg_max_value

        case PARAM_EMG_MAX_VALUE:
            *((uint32 *)(packet_data + 1)) = c_mem.emg_max_value[0];
            *((uint32 *)(packet_data + 5)) = c_mem.emg_max_value[1];
            packet_lenght = 10;
            break;

//============================================================     get_emg_speed

        case PARAM_EMG_SPEED:
            *((uint8 *)(packet_data + 1)) = c_mem.emg_speed;
            packet_lenght = 3;
            break;

//================================================     get_double_encoder_on_off
        case PARAM_DOUBLE_ENC_ON_OFF:
            *((uint8 *)(packet_data + 1)) = c_mem.double_encoder_on_off;
            packet_lenght = 3;
            break;

//===================================================     get_motor_handle_ratio
        case PARAM_MOT_HANDLE_RATIO:
            *((int8 *)(packet_data + 1)) = c_mem.motor_handle_ratio;
            packet_lenght = 3;
            break;

//===================================================     get_motor_supply_type
        case PARAM_MOTOR_SUPPLY:
            *((uint8 *)(packet_data + 1)) = c_mem.activate_pwm_rescaling;
            packet_lenght = 3;
            break;

//===================================================     default
        default:
            break;
    }

    packet_data[packet_lenght - 1] = LCRChecksum(packet_data,packet_lenght - 1);
    commWrite(packet_data, packet_lenght);
}

//==============================================================================
//                                                           PREPARE DEVICE INFO
//==============================================================================

void infoPrepare(unsigned char *info_string)
{
    int i;
    if(c_mem.id != 250){                //To avoid dummy board ping
        unsigned char str[100];
        strcpy(info_string, "");
        strcat(info_string, "\r\n");
        strcat(info_string, "Firmware version: ");
        strcat(info_string, VERSION);
        strcat(info_string, ".\r\n\r\n");

        strcat(info_string, "DEVICE INFO\r\n");
        sprintf(str, "ID: %d\r\n", (int) c_mem.id);
        strcat(info_string, str);
        strcat(info_string, "PWM rescaling activation: ");
        if(c_mem.activate_pwm_rescaling == MAXON_12V)
            strcat(info_string, "YES\n");
        else
            strcat(info_string, "NO\n");
        
        sprintf(str, "PWM Limit: %d\r\n", (int) dev_pwm_limit);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        strcat(info_string, "MOTOR INFO\r\n");
        strcat(info_string, "Motor reference");
        
        if(g_mem.control_mode == CONTROL_CURRENT)
            strcat(info_string," - Currents: ");
        else {
            if (g_mem.control_mode == CONTROL_PWM)
                strcat(info_string," - Pwm: ");
            else
                strcat(info_string," - Position: ");
        }
    
        for (i = 0; i < NUM_OF_MOTORS; i++) {
            if(g_mem.control_mode == CONTROL_CURRENT) {
                sprintf(str, "%d ", (int)(g_ref.curr[i]));
                strcat(info_string,str);
            }
        else {
            if(g_mem.control_mode == CONTROL_PWM) {
                sprintf(str, "%d ", (int)(g_ref.pwm[i]));
                strcat(info_string,str);
            }
            else {
                sprintf(str, "%d ", (int)(g_ref.pos[i] >> c_mem.res[i]));
                strcat(info_string,str);
            }
        }
    }
    strcat(info_string,"\r\n");
        strcat(info_string, "\r\n");

        sprintf(str, "Motor enabled: ");
        if (g_ref.onoff & 0x03) {
            strcat(str, "YES\r\n");
        } else {
            strcat(str, "NO\r\n");
        }
        strcat(info_string, str);

        strcat(info_string, "\r\nMEASUREMENTS INFO\r\n");
        strcat(info_string, "Sensor value:\r\n");
        for (i = 0; i < NUM_OF_SENSORS; i++) {
            sprintf(str, "%d -> %d", i+1,
            (int)(g_meas.pos[i] >> c_mem.res[i]));
            strcat(info_string, str);
            strcat(info_string, "\r\n");
        }

        sprintf(str, "Voltage (mV): %ld", (int32) dev_tension );
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        sprintf(str, "Current (mA): %ld", (int32) g_meas.curr[0] );
        strcat(info_string, str);
        strcat(info_string, "\r\n");


        strcat(info_string, "\r\nDEVICE PARAMETERS\r\n");

        strcat(info_string, "PID Controller:\r\n");
        sprintf(str, "P -> %f  ", ((double) c_mem.k_p / 65536));
        strcat(info_string, str);
        sprintf(str, "I -> %f  ", ((double) c_mem.k_i / 65536));
        strcat(info_string, str);
        sprintf(str, "D -> %f\r\n", ((double) c_mem.k_d / 65536));
        strcat(info_string, str);

        strcat(info_string, "Current PID Controller:\r\n");
        sprintf(str, "P -> %f  ", ((double) c_mem.k_p_c / 65536));
        strcat(info_string, str);
        sprintf(str, "I -> %f  ", ((double) c_mem.k_i_c / 65536));
        strcat(info_string, str);
        sprintf(str, "D -> %f\r\n", ((double) c_mem.k_d_c / 65536));
        strcat(info_string, str);

        strcat(info_string, "\r\n");


        if (c_mem.activ == 0x03) {
            strcat(info_string, "Startup activation: YES\r\n");
        } else {
            strcat(info_string, "Startup activation: NO\r\n");
        }

        switch(c_mem.input_mode) {
            case INPUT_MODE_EXTERNAL:
                strcat(info_string, "Input mode: USB\r\n");
                break;
            case INPUT_MODE_ENCODER3:
                strcat(info_string, "Input mode: Handle\r\n");
                break;
            case INPUT_MODE_EMG_PROPORTIONAL:
                strcat(info_string, "Input mode: EMG proportional\r\n");
                break;
            case INPUT_MODE_EMG_INTEGRAL:
                strcat(info_string, "Input mode: EMG integral\r\n");
                break;
            case INPUT_MODE_EMG_FCFS:
                strcat(info_string, "Input mode: EMG FCFS\r\n");
                break;
            case INPUT_MODE_EMG_FCFS_ADV:
                strcat(info_string, "Input mode: EMG FCFS ADV\r\n");
                break;
        }

        switch(c_mem.control_mode) {
            case CONTROL_ANGLE:
                strcat(info_string, "Control mode: Position\r\n");
                break;
            case CONTROL_PWM:
                strcat(info_string, "Control mode: PWM\r\n");
                break;
            case CONTROL_CURRENT:
                strcat(info_string, "Control mode: Current\r\n");
                break;
            case CURR_AND_POS_CONTROL:
                strcat(info_string, "Control mode: Current and Position\r\n");
                break;
            default:
                break;
        }

        if (c_mem.double_encoder_on_off) {
            strcat(info_string, "Absolute encoder position: YES\r\n");
        } else {
            strcat(info_string, "Absolute encoder position: NO\r\n");
        }

        sprintf(str, "Motor-Handle Ratio: %d\r\n", (int)c_mem.motor_handle_ratio);
        strcat(info_string, str);



        strcat(info_string, "Sensor resolution:\r\n");
        for (i = 0; i < NUM_OF_SENSORS; ++i) {
            sprintf(str, "%d -> %d", (int) (i + 1), (int) c_mem.res[i]);
            strcat(info_string, str);
            strcat(info_string, "\r\n");
        }


        strcat(info_string, "Measurement Offset:\r\n");
        for (i = 0; i < NUM_OF_SENSORS; ++i) {
            sprintf(str, "%d -> %ld", (int) (i + 1), (int32) c_mem.m_off[i] >> c_mem.res[i]);
            strcat(info_string, str);
            strcat(info_string, "\r\n");
        }

        strcat(info_string, "Measurement Multiplier:\r\n");
        for (i = 0; i < NUM_OF_SENSORS; ++i) {
            sprintf(str,"%d -> %f", (int)(i + 1), (double) c_mem.m_mult[i]);
            strcat(info_string, str);
            strcat(info_string,"\r\n");
        }

        sprintf(str, "Position limit active: %d", (int)g_mem.pos_lim_flag);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        for (i = 0; i < NUM_OF_MOTORS - 1; i++) {
            sprintf(str, "Position limit motor %d: inf -> %ld  ", (int)(i + 1),
            (int32)g_mem.pos_lim_inf[i] >> g_mem.res[i]);
            strcat(info_string, str);

            sprintf(str, "sup -> %ld\r\n",
            (int32)g_mem.pos_lim_sup[i] >> g_mem.res[i]);
            strcat(info_string, str);
        }

        sprintf(str, "Max step pos and neg: %d %d", (int)g_mem.max_step_pos, (int)g_mem.max_step_neg);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        sprintf(str, "Current limit: %d", (int)g_mem.current_limit);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        sprintf(str, "EMG thresholds [0 - 1024]: %u, %u", g_mem.emg_threshold[0], g_mem.emg_threshold[1]);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        sprintf(str, "EMG max values [0 - 4096]: %lu, %lu", g_mem.emg_max_value[0], g_mem.emg_max_value[1]);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        if (g_mem.emg_calibration_flag) {
            strcat(info_string, "Calibration enabled: YES\r\n");
        } else {
            strcat(info_string, "Calibration enabled: NO\r\n");
        }

        sprintf(str, "EMG max speed: %d", (int)g_mem.emg_speed);
        strcat(info_string, str);
        strcat(info_string, "\r\n");

        sprintf(str, "debug: %ld", (uint32)timer_value0 - (uint32)timer_value); //5000001
        strcat(info_string, str);
        strcat(info_string, "\r\n");
    }
}

//==============================================================================
//                                                      WRITE FUNCTION FOR RS485
//==============================================================================

void commWrite(uint8 *packet_data, const uint8 packet_lenght)
{
    uint16 CYDATA index;

    // frame - start
    UART_RS485_PutChar(':');
    UART_RS485_PutChar(':');
    
    // frame - ID
    UART_RS485_PutChar(g_mem.id);
    
    // frame - length
    UART_RS485_PutChar(packet_lenght);
    
    // frame - packet data
    for(index = 0; index < packet_lenght; ++index)
        UART_RS485_PutChar(packet_data[index]);
    
    index = 0;

    while(!(UART_RS485_ReadTxStatus() & UART_RS485_TX_STS_COMPLETE) && index++ <= 1000){}

    RS485_CTS_Write(1);
    RS485_CTS_Write(0);
}


//==============================================================================
//                                                             CHECKSUM FUNCTION
//==============================================================================

// Performs a XOR byte by byte on the entire vector

uint8 LCRChecksum(uint8 *data_array, uint8 data_length) {
    
    uint8 CYDATA i;
    uint8 CYDATA checksum = 0x00;
    
    for(i = 0; i < data_length; ++i)
       checksum ^= data_array[i];
  
    return checksum;
}

//==============================================================================
//                                                       ACKNOWLEDGMENT FUNCTION
//==============================================================================

void sendAcknowledgment(const uint8 value) {
    int packet_lenght = 2;
    uint8 packet_data[2];

    packet_data[0] = value;
    packet_data[1] = value;

    commWrite(packet_data, packet_lenght);
}

//==============================================================================
//                                                                  STORE MEMORY
//==============================================================================

/**
* This function stores current memory settings on the eeprom with the specified
* displacement
**/

uint8 memStore(int displacement)
{
    int i;  // iterator
    uint8 writeStatus;
    int pages;
    uint8 ret_val = 1;

    // Disable Interrupt
    ISR_RS485_RX_Disable();

    // Stop motors
    PWM_MOTORS_WriteCompare1(0);
    PWM_MOTORS_WriteCompare2(0);

    // Retrieve temperature for better writing performance
    CySetTemp();

    memcpy( &c_mem, &g_mem, sizeof(g_mem) );

    pages = sizeof(g_mem) / 16 + (sizeof(g_mem) % 16 > 0);

    for(i = 0; i < pages; ++i) {
        writeStatus = EEPROM_Write(&g_mem.flag + 16 * i, i + displacement);
        if(writeStatus != CYRET_SUCCESS) {
            ret_val = 0;
            break;
        }
    }

    memcpy( &g_mem, &c_mem, sizeof(g_mem) );

    // Re-Enable Interrupt
    ISR_RS485_RX_Enable();

    return ret_val;
}


//==============================================================================
//                                                                 RECALL MEMORY
//==============================================================================

/**
* This function loads user settings from the eeprom.
**/

void memRecall()
{
    uint16 i;

    for (i = 0; i < sizeof(g_mem); i++) {
        ((reg8 *) &g_mem.flag)[i] = EEPROM_ADDR[i];
    }

    //check for initialization
    if (g_mem.flag == FALSE) {
        memRestore();
    } else {
        memcpy( &c_mem, &g_mem, sizeof(g_mem) );
    }
}


//==============================================================================
//                                                                RESTORE MEMORY
//==============================================================================

/**
* This function loads default settings from the eeprom.
**/

uint8 memRestore() {
    uint16 i;

    for (i = 0; i < sizeof(g_mem); i++) {
        ((reg8 *) &g_mem.flag)[i] = EEPROM_ADDR[i + (DEFAULT_EEPROM_DISPLACEMENT * 16)];
    }

    //check for initialization
    if (g_mem.flag == FALSE) {
        return memInit();
    } else {
        return memStore(0);
    }
}

//==============================================================================
//                                                                   MEMORY INIT
//==============================================================================

/**
* This function initialize memory when eeprom is compromised.
**/

uint8 memInit()
{
    uint8 i;

    //initialize memory settings
    g_mem.id            = 1;

    g_mem.k_p           = 0.015 * 65536;
    g_mem.k_i           =  0.02 * 65536;
    g_mem.k_d           = 0.007 * 65536;  //Changed in order to avoid metallic clatter previous value 0.2
    g_mem.k_p_c         =     1 * 65536;
    g_mem.k_i_c         = 0.001 * 65536;
    g_mem.k_d_c         =     0 * 65536;

    g_mem.activ         = 0;
    g_mem.input_mode    = INPUT_MODE_EXTERNAL;
    g_mem.control_mode  = CONTROL_ANGLE;

    g_mem.pos_lim_flag = 1;

    g_mem.activate_pwm_rescaling = MAXON_24V;           //rescaling active for 12V motors

    g_mem.res[0] = 3;
    g_mem.res[1] = 3;
    g_mem.res[2] = 3;

    for (i = 0; i < NUM_OF_MOTORS; i++) {
        g_mem.pos_lim_inf[i] = 0;
        g_mem.pos_lim_sup[i] = (int32)19000 << g_mem.res[0];
    }

    for(i = 0; i < NUM_OF_SENSORS; ++i)
    {
        g_mem.m_mult[i] = 1;
        g_mem.m_off[i] = (int32)0 << g_mem.res[i];
    }

    g_mem.max_step_pos = 0;
    g_mem.max_step_neg = 0;

    g_mem.current_limit = DEFAULT_CURRENT_LIMIT;

    // EMG calibration enabled by default
    g_mem.emg_calibration_flag = 0;

    g_mem.emg_max_value[0] = 0;
    g_mem.emg_max_value[1] = 0;

    g_mem.emg_threshold[0] = 100;
    g_mem.emg_threshold[1] = 100;

    g_mem.emg_speed = 100;

    g_mem.double_encoder_on_off = 1;
    g_mem.motor_handle_ratio = 22;

    // set the initialized flag to show EEPROM has been populated
    g_mem.flag = TRUE;
    
    //write that configuration to EEPROM
    return ( memStore(0) && memStore(DEFAULT_EEPROM_DISPLACEMENT) );
}

//==============================================================================
//                                                    ROUTINE INTERRUPT FUNCTION
//==============================================================================
/**
* Bunch of functions used on request from UART communication
**/

void cmd_get_measurements(){
 
    uint8 CYDATA index;
   
    // Packet: header + measure(int16) + crc
    
    uint8 packet_data[8]; 
    
    //Header package
    packet_data[0] = CMD_GET_MEASUREMENTS;   
    
    for (index = NUM_OF_SENSORS; index--;) 
        *((int16 *) &packet_data[(index << 1) + 1]) = (int16)(g_measOld.pos[index] >> g_mem.res[index]);
            
    // Calculate Checksum and send message to UART 

    packet_data[7] = LCRChecksum (packet_data, 7);

    commWrite(packet_data, 8);
   
}

void cmd_set_inputs(){
    
    // Store position setted in right variables

    if(g_mem.control_mode == CONTROL_CURRENT) {
        g_refNew.curr[0] = *((int16 *) &g_rx.buffer[1]);
        g_refNew.curr[1] = *((int16 *) &g_rx.buffer[3]);
    }
    else {
        if(g_mem.control_mode == CONTROL_PWM) {
            g_refNew.pwm[0] = *((int16 *) &g_rx.buffer[1]);
            g_refNew.pwm[1] = *((int16 *) &g_rx.buffer[3]);
        }
        else {
            g_refNew.pos[0] = *((int16 *) &g_rx.buffer[1]);   // motor 1
            g_refNew.pos[0] = g_refNew.pos[0] << g_mem.res[0];

            g_refNew.pos[1] = *((int16 *) &g_rx.buffer[3]);   // motor 2
            g_refNew.pos[1] = g_refNew.pos[1] << g_mem.res[1];
        }
    }

    // Check Position Limit cmd

    if (c_mem.pos_lim_flag && 
        (g_mem.control_mode == CURR_AND_POS_CONTROL
        || g_mem.control_mode == CONTROL_ANGLE)) {                      // pos limiting
        
        if (g_refNew.pos[0] < c_mem.pos_lim_inf[0]) 
            g_refNew.pos[0] = c_mem.pos_lim_inf[0];
        if (g_refNew.pos[1] < c_mem.pos_lim_inf[1]) 
            g_refNew.pos[1] = c_mem.pos_lim_inf[1];

        if (g_refNew.pos[0] > c_mem.pos_lim_sup[0]) 
            g_refNew.pos[0] = c_mem.pos_lim_sup[0];
        if (g_refNew.pos[1] > c_mem.pos_lim_sup[1]) 
            g_refNew.pos[1] = c_mem.pos_lim_sup[1];
    }
}

void cmd_activate(){
    
    // Store new value reads
    g_refNew.onoff = g_rx.buffer[1];
    
    // Check type of control mode enabled
    if ((g_mem.control_mode == CONTROL_ANGLE) || (g_mem.control_mode == CURR_AND_POS_CONTROL)) {
        g_refNew.pos[0] = g_meas.pos[0];
        g_refNew.pos[1] = g_meas.pos[1];
    }

    // Activate/Disactivate motors
    MOTOR_ON_OFF_Write(g_refNew.onoff);
}

void cmd_get_activate(){
    
    uint8 packet_data[3];

    // Header        
    packet_data[0] = CMD_GET_ACTIVATE;
    
    // Fill payload
    packet_data[1] = g_ref.onoff;
    
    // Calculate checksum
    packet_data[2] = LCRChecksum(packet_data, 2);
    
    // Send package to UART
    commWrite(packet_data, 3);

}

void cmd_get_curr_and_meas(){
    
    uint8 CYDATA index;
   
    //Packet: header + curr_meas(int16) + pos_meas(int16) + CRC
    
    uint8 packet_data[12]; 

    //Header package
    packet_data[0] = CMD_GET_CURR_AND_MEAS;
    
    // Currents
    *((int16 *) &packet_data[1]) = (int16) g_measOld.curr[0];
    *((int16 *) &packet_data[3]) = (int16) g_measOld.curr[1];

    // Positions
    for (index = NUM_OF_SENSORS; index--;) 
        *((int16 *) &packet_data[(index << 2) + 5]) = (int16) (g_measOld.pos[index] >> g_mem.res[index]);
        
    // Calculate Checksum and send message to UART 
        
    packet_data[11] = LCRChecksum (packet_data, 11);
    commWrite(packet_data, 12);
   
}

void cmd_get_currents(){
    
    // Packet: header + motor_measure(int16) + crc
    
    uint8 packet_data[6]; 
    
    //Header package

    packet_data[0] = CMD_GET_CURRENTS;

    *((int16 *) &packet_data[1]) = (int16) g_measOld.curr[0];
    *((int16 *) &packet_data[3]) = (int16) g_measOld.curr[1];

    // Calculate Checksum and send message to UART 

    packet_data[5] = LCRChecksum (packet_data, 5);

    commWrite(packet_data, 6);
}

void cmd_set_baudrate(){
    
    // Set BaudRate
    c_mem.baud_rate = g_rx.buffer[1];
    
    switch(g_rx.buffer[1]){
        case 13:
            CLOCK_UART_SetDividerValue(13);
            break;
        default:
            CLOCK_UART_SetDividerValue(3);
    }
}

void cmd_ping(){

    uint8 packet_data[2];

    // Header
    packet_data[0] = CMD_PING;
    
    // Load Payload
    packet_data[1] = CMD_PING;

    // Send Package to uart
    commWrite(packet_data, 2);
}

void cmd_set_watchdog(){
      
    if (g_rx.buffer[1] <= 0){
        // Deactivate Watchdog
        WATCHDOG_ENABLER_Write(1); 
        g_mem.watchdog_period = 0;   
    }
    else{
        // Activate Watchdog        
        if (g_rx.buffer[1] > MAX_WATCHDOG_TIMER)
            g_rx.buffer[1] = MAX_WATCHDOG_TIMER;
            
        // Period * Time_CLK = WDT
        // Period = WTD / Time_CLK =     (WTD    )  / ( ( 1 / Freq_CLK ) )
        // Set request watchdog period - (WTD * 2)  * (250 / 1024        )
        g_mem.watchdog_period = (uint8) (((uint32) g_rx.buffer[1] * 2 * 250 ) >> 10);   
        WATCHDOG_COUNTER_WritePeriod(g_mem.watchdog_period); 
        WATCHDOG_ENABLER_Write(0); 
    }
}

void cmd_get_inputs(){

    // Packet: header + motor_measure(int16) + crc

    uint8 packet_data[6]; 
    
    //Header package

    packet_data[0] = CMD_GET_INPUTS;
    
    *((int16 *) &packet_data[1]) = (int16) (g_refOld.pos[0]  >> g_mem.res[0]);
    *((int16 *) &packet_data[3]) = (int16) (g_refOld.pos[1]  >> g_mem.res[1]);
    
    // Calculate Checksum and send message to UART 

    packet_data[5] = LCRChecksum(packet_data, 5);

    commWrite(packet_data, 6);
}

void cmd_store_params(){
    
    // Check input mode enabled
    uint32 off_1, off_2;
    float mult_1, mult_2;
    
    if( c_mem.input_mode == INPUT_MODE_EXTERNAL ) {
        off_1 = c_mem.m_off[0];
        off_2 = c_mem.m_off[1];
        mult_1 = c_mem.m_mult[0];
        mult_2 = c_mem.m_mult[1];

        g_refNew.pos[0] = (int32)((float)g_refNew.pos[0] / mult_1);
        g_refNew.pos[1] = (int32)((float)g_refNew.pos[1] / mult_2);

        g_refNew.pos[0] = (int32)((float)g_refNew.pos[0] * g_mem.m_mult[0]);
        g_refNew.pos[1] = (int32)((float)g_refNew.pos[1] * g_mem.m_mult[1]);

        g_refNew.pos[0] += (g_mem.m_off[0] - off_1);
        g_refNew.pos[1] += (g_mem.m_off[1] - off_2);
        
        // Check position Limits

        if (c_mem.pos_lim_flag) {                   // position limiting
            if (g_refNew.pos[0] < c_mem.pos_lim_inf[0]) 
                g_refNew.pos[0] = c_mem.pos_lim_inf[0];
            if (g_refNew.pos[1] < c_mem.pos_lim_inf[1]) 
                g_refNew.pos[1] = c_mem.pos_lim_inf[1];

            if (g_refNew.pos[0] > c_mem.pos_lim_sup[0]) 
                g_refNew.pos[0] = c_mem.pos_lim_sup[0];
            if (g_refNew.pos[1] > c_mem.pos_lim_sup[1]) 
                g_refNew.pos[1] = c_mem.pos_lim_sup[1];
        }
    }
    // Store params 

    if(memStore(0))
        sendAcknowledgment(ACK_OK);
    else
        sendAcknowledgment(ACK_ERROR);
}

void cmd_get_emg(){
    
    uint8 packet_data[6];

    // Header        
    packet_data[0] = CMD_GET_EMG;
    
    *((int16 *) &packet_data[1]) = (int16) g_measOld.emg[0];
    *((int16 *) &packet_data[3]) = (int16) g_measOld.emg[1];

    packet_data[5] = LCRChecksum (packet_data, 5);

    commWrite(packet_data, 6);

}

/* [] END OF FILE */