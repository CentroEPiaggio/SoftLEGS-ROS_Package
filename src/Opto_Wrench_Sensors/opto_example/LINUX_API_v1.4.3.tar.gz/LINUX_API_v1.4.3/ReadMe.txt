The OptoForce API requires Qt 5 framework to run properly.

If Qt 5 is not installed then the necessary files should be copied from QtLIBS.tar.gz to the /lib directory of your Linux system.

Superuser rights might be necessary to access the DAQ through ttyACM0.

The most current version and the documentation of the API can be downloaded from http://www.optoforce.com/support.
